/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HomeWork;

import java.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Comparator;

/**
 *
 * @author lenovo
 */
public class HomeWork{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        Student s1 = new ItStudent(1, "basem", "Twf", 0 ,2, 10);
        Student s2 = new ItStudent(2, "baraa", "abed", 35, 16, 20);

        Student s4 = new ArtStudent(4, "nael", "abed", 12, 2,20);
        Student s3 = new ArtStudent(3, "malek", "abed", 15, 45, 25);
        Student[] s = {s1, s2, s3, s4};

//        way 1
        List<Student> sList = Arrays.asList(s);      
//        studentList=studentList.stream().sorted(Comparator.comparing(Student :: getGrade)).collect(Collectors.toList());
//       for(Student lis:List){
//            System.out.println(lis);}
 PrintWriter output = new PrintWriter(new File("src/ass1/stu.data"));
//            for(Student lis:sList){
//           output.println(lis);}
//       output.close();
      

       
     
    }
}
